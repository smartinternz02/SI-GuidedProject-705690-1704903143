<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Help  Settings</name>
   <tag></tag>
   <elementGuidId>e0dead3d-41be-4cb5-b28e-d1cf2710a0f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>903c9e4e-e91c-46bb-a9d5-0ec2edde7f3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hmenu-item hmenu-title </value>
      <webElementGuid>1bc999e4-b8e5-4f58-b823-be04e2756582</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Help &amp; Settings</value>
      <webElementGuid>934ee9af-8f60-4ece-abaa-26ec9a728f4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[29]/div[@class=&quot;hmenu-item hmenu-title&quot;]</value>
      <webElementGuid>89e03d0f-f8cd-4742-990d-767aa5e9b62f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[29]/div</value>
      <webElementGuid>cf493022-2fdf-4cbb-9b38-fadb1aee65e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[29]/div</value>
      <webElementGuid>7eb2bafa-5817-45db-a785-dc61f43a43d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      <webElementGuid>fd629ae1-61d1-4cc6-b233-6e2e70a7fc51</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
