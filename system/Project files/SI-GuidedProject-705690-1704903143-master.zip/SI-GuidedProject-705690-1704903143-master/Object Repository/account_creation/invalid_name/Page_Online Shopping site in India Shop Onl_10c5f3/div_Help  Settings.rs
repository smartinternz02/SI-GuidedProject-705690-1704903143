<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Help  Settings</name>
   <tag></tag>
   <elementGuidId>371b0299-a1f9-45cb-b3f3-b644ff00ecd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f2a9e656-9b2a-40e5-92fe-61e60593a796</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hmenu-item hmenu-title </value>
      <webElementGuid>a691ea75-0f27-4ccb-b078-6801d3ab9b85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Help &amp; Settings</value>
      <webElementGuid>a63fdb63-cb91-4244-aea1-7067b2950cdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[28]/div[@class=&quot;hmenu-item hmenu-title&quot;]</value>
      <webElementGuid>f48521c1-6b62-48c2-b04a-c5cfb1a191f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[28]/div</value>
      <webElementGuid>8d682670-3545-4717-96c4-341d411aecde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[28]/div</value>
      <webElementGuid>aac553d3-a0aa-4da1-87ba-8728e24da0f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      <webElementGuid>7647be34-e149-4205-b937-cd706483af1d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
