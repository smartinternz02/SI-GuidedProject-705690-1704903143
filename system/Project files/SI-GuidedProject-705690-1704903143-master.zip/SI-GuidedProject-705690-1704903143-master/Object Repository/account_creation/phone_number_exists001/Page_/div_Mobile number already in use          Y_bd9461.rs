<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mobile number already in use          Y_bd9461</name>
   <tag></tag>
   <elementGuidId>baab1159-ec77-4da2-9da1-3f45616a9b91</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-box.a-alert.a-alert-warning.a-spacing-base > div.a-box-inner.a-alert-container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='authportal-main-section']/div[2]/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>012773bb-eb1c-404f-b6a7-8539fc9a80ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner a-alert-container</value>
      <webElementGuid>5ca8f77c-7c3e-46b0-917f-a0fc3422fda8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mobile number already in use
    
      You indicated you are a new customer, but an account already exists with the mobile number +917779970102
    
  </value>
      <webElementGuid>793010ef-d68d-48af-a67a-f1ae70d11088</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-double-large&quot;]/div[@class=&quot;a-section a-spacing-large&quot;]/div[@class=&quot;a-box a-alert a-alert-warning a-spacing-base&quot;]/div[@class=&quot;a-box-inner a-alert-container&quot;]</value>
      <webElementGuid>620ccac7-6c00-4dab-b6a7-4c6d438f6395</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div/div/div/div</value>
      <webElementGuid>bc22d741-334e-4967-b28f-307ac10d7f6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div/div/div</value>
      <webElementGuid>d4c8ba6a-54c2-4471-890f-05d338bcecf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Mobile number already in use
    
      You indicated you are a new customer, but an account already exists with the mobile number +917779970102
    
  ' or . = 'Mobile number already in use
    
      You indicated you are a new customer, but an account already exists with the mobile number +917779970102
    
  ')]</value>
      <webElementGuid>dee36963-7582-4b21-b2f1-ecb383cab239</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
