<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Help  Settings</name>
   <tag></tag>
   <elementGuidId>d40a7e6f-bf55-4861-a0cf-79e8d3bacec0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4fbab700-d5c0-488c-b769-01fc5df89842</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hmenu-item hmenu-title </value>
      <webElementGuid>803c503d-c991-44ed-8ef4-f92f475f3a69</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Help &amp; Settings</value>
      <webElementGuid>f87869d9-0b9d-43b1-ab42-beb20b0450f2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[29]/div[@class=&quot;hmenu-item hmenu-title&quot;]</value>
      <webElementGuid>136e8ede-e30a-4c6c-9be7-ba4a0c6b12de</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[29]/div</value>
      <webElementGuid>142ea567-02d5-4d08-8ec2-2c26cb2b7b28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[29]/div</value>
      <webElementGuid>59a4c8c9-138c-422d-af20-34fa8772115f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Help &amp; Settings' or . = 'Help &amp; Settings')]</value>
      <webElementGuid>7d0e6eea-c682-4da1-aff4-377271faa057</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
