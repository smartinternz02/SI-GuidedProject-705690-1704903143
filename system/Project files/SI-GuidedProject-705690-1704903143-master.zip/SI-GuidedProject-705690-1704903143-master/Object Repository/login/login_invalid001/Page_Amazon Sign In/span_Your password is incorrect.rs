<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Your password is incorrect</name>
   <tag></tag>
   <elementGuidId>77f26f4a-9efa-4e9f-b406-2ca209a75703</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-list-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>13e7b753-61bd-4819-aeab-0118d5059c84</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-list-item</value>
      <webElementGuid>703c7242-46b1-47af-9bf2-1fbe0a213b9b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Your password is incorrect
          </value>
      <webElementGuid>48ff1ccf-3d87-405a-bf9b-ba64824e4779</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical a-spacing-none&quot;]/li[1]/span[@class=&quot;a-list-item&quot;]</value>
      <webElementGuid>e4fd3384-6b87-4375-b3c2-4117e132f668</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      <webElementGuid>5c7102b5-e624-4fe7-bee1-d8c2193ac696</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>62dd9791-f1c6-4a17-b2d4-2df841816247</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            Your password is incorrect
          ' or . = '
            Your password is incorrect
          ')]</value>
      <webElementGuid>15487404-455b-426c-a480-d8954a4e377d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
