<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_1                                        _7d74ab</name>
   <tag></tag>
   <elementGuidId>e387c6c3-4055-4a43-9924-c4d5a8528460</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>35d750e3-bd4e-485d-aac8-5eaeeeb07d03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.amazon.in/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>19b5c43d-0317-47a3-9a8d-e056c0653397</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>1 item in cart</value>
      <webElementGuid>40ba9b30-a210-44e4-896b-5bd238ef2fc9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>15aa5a51-8544-48e2-9741-596d8c8a5e0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>38fc5889-aa16-478a-a972-efdcf447651e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>6f52e280-42b0-4a05-b044-969c704b361a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>d7cfe3df-85b3-4718-80d6-aab0783fda36</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>2d74e17e-1d1e-41e2-815a-b7579f3b5518</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>5e095a68-d304-4685-b3bf-a3a3f6dd7240</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.amazon.in/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>b913b937-f712-47a5-a63b-d32c76ce6631</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>5ed166d1-55ce-4bf4-ab94-7046d2f692ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.amazon.in/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  ' or . = '
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>fc327957-30ae-427b-85ec-55cb40c2e336</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
