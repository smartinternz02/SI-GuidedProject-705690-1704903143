<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mobiles, Computers</name>
   <tag></tag>
   <elementGuidId>80739602-5225-4792-833b-4ea411e620d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[16]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(16) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fd9a1d5f-6afa-4f94-9b6c-d0580eb2bb96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mobiles, Computers</value>
      <webElementGuid>a4cc489c-7db0-49a5-a69c-d7f2174fb52a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[16]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>558ac50b-05f1-4798-9bea-19c5d05a9a67</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[16]/a/div</value>
      <webElementGuid>08bb96ec-8749-4c73-9cbd-d25cc9d729c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[16]/a/div</value>
      <webElementGuid>55b486ba-4fe7-472b-9c0f-27428bb8f5c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Mobiles, Computers' or . = 'Mobiles, Computers')]</value>
      <webElementGuid>5095e1ef-e695-4f6b-9bef-033dc2dc70f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
