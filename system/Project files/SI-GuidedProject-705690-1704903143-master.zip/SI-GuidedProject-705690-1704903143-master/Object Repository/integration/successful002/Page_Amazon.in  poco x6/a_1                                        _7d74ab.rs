<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_1                                        _7d74ab</name>
   <tag></tag>
   <elementGuidId>95de60d6-d5e1-407a-bdc8-7638900cf379</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5efff971-4c7b-4e9c-99c1-d659dbf3e690</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.amazon.in/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>041b821b-a4e8-421c-b9e6-966603e2791f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>1 item in cart</value>
      <webElementGuid>88a89822-f2a8-4079-82d8-539956a4e1d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>2b5b4360-7401-46e2-90f4-83c7ca5a54f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>3e1fbdbd-aa2f-4a2b-93cf-855cdef456c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>5f2751d3-51a5-447d-8d13-e9ab1b2e3724</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>a9ad8dd8-b845-438e-8908-ccf07669170b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>594b2776-07bd-46f9-9d40-fd82e559d16a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>83a0c421-fe60-42a6-bc92-17e1f0968675</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.amazon.in/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>b21038db-2e78-449a-9919-2ac4cb1c53f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>0f0a25cd-6c5d-4ab5-8634-fec18bf3c27b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.amazon.in/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  ' or . = '
    
      1
      
    
    
      
         
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>8c1a1aa5-788e-4f2f-9459-f440c94015c2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
