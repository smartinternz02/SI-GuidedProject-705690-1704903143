Amazon Web automation testing.
